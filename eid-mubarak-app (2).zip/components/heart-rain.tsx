"use client"

import type React from "react"

import { useState, useEffect } from "react"

interface HeartRainProps {
  active: boolean
}

export function HeartRain({ active }: HeartRainProps) {
  const [hearts, setHearts] = useState<Array<{ id: number; style: React.CSSProperties }>>([])

  useEffect(() => {
    if (!active) return

    // Create initial hearts
    const initialHearts = Array.from({ length: 15 }, (_, i) => createHeart(i))
    setHearts(initialHearts)

    // Add new hearts periodically
    const interval = setInterval(() => {
      setHearts((prevHearts) => {
        // Remove some old hearts to prevent too many elements
        const filtered = prevHearts.filter((_, i) => i > prevHearts.length - 20)
        return [...filtered, createHeart(Date.now())]
      })
    }, 500)

    return () => clearInterval(interval)
  }, [active])

  if (!active) return null

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-10">
      {hearts.map((heart) => (
        <div key={heart.id} className="absolute text-red-500" style={heart.style}>
          {heart.id % 5 === 0 ? "❤️" : "💖"}
        </div>
      ))}
    </div>
  )
}

function createHeart(id: number) {
  const size = Math.floor(Math.random() * 16) + 16 // 16-32px
  const startX = Math.random() * 100 // 0-100% of screen width
  const animationClass = `animate-heart-fall-${(id % 5) + 1}`
  const delay = Math.random() * 3 // 0-3s delay

  return {
    id,
    style: {
      left: `${startX}%`,
      top: "0",
      fontSize: `${size}px`,
      animationDelay: `${delay}s`,
    } as React.CSSProperties,
    className: animationClass,
  }
}
